// hacky way to test that it still works when Symbol is not there
global.Symbol = false
require('./basic.js')
