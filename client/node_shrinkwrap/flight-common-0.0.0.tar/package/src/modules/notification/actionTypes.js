/*=============================================================================
 * Copyright (C) 2015 Stephen F. Norledge and Alces Software Ltd.
 *
 * This file is part of Alces FlightDeck.
 *
 * All rights reserved, see LICENSE.txt.
 *===========================================================================*/
export const ADD_ERROR_MODAL = 'notification/ADD_ERROR_MODAL';
export const ADD_INFO_MODAL  = 'notification/ADD_INFO_MODAL';
export const CLOSE_MODAL     = 'notification/CLOSE_MODAL'
