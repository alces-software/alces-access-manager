### Version 0.2.0 (2015-02-21) ###

- Improved: You may now pass an already split string as an array.
- Changed: `options.transform` is now passed an object with all the elements of
  the current line, allowing you to modify any part of it.
  (Backwards-incompatible change.)


### Version 0.1.0 (2014-12-20) ###

- Initial release.
