v0.2.1 - Fri, 23 Oct 2015 18:16:47 GMT
--------------------------------------

- [8e2c5c0](../../commit/8e2c5c0) [fixed] Removing ReactDOM from bundle


v0.2.0 - Thu, 22 Oct 2015 07:20:40 GMT
--------------------------------------

- [35d6109](../../commit/35d6109) [added] support for react@0.14.0


v0.1.2 - Tue, 14 Jul 2015 04:52:52 GMT
--------------------------------------

- [6d1c2a1](../../commit/6d1c2a1) [fixed] Hiding flipped side to prevent tab focus


v0.1.1 - Sun, 12 Jul 2015 11:24:57 GMT
--------------------------------------

- 


v0.1.0 - Sun, 12 Jul 2015 10:10:13 GMT
--------------------------------------

- 


