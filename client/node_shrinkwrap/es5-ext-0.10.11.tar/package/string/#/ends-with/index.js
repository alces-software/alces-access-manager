'use strict';

module.exports = require('./is-implemented')()
	? String.prototype.endsWith
	: require('./shim');
