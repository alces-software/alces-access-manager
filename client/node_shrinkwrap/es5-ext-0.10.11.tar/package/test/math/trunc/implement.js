'use strict';

var isImplemented = require('../../../math/trunc/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
