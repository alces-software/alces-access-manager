'use strict';

var isImplemented = require('../../../../array/#/splice/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
