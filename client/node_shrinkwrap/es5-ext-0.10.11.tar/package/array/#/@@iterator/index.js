'use strict';

module.exports = require('./is-implemented')()
	? Array.prototype[require('es6-symbol').iterator] : require('./shim');
