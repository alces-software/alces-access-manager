export default function tokenize(input: any): any[];
