## 1.1.0 (March 19, 2016)

- Command#extend() accepts parameters for passed function now
- implement Command#end() method to return to parent command definition
- fix suggestion bugs and add tests

## 1.0.0 (Oct 12, 2014)

- Initial release
