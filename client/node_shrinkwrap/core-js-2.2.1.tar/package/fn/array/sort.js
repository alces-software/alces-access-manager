require('../../modules/es6.array.sort');
module.exports = require('../../modules/_core').Array.sort;