require('../../../modules/es6.array.reduce');
module.exports = require('../../../modules/_entry-virtual')('Array').reduce;