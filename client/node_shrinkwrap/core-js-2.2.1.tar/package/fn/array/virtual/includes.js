require('../../../modules/es7.array.includes');
module.exports = require('../../../modules/_entry-virtual')('Array').includes;