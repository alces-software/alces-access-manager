require('../../../modules/es6.number.to-precision');
module.exports = require('../../../modules/_entry-virtual')('Number').toPrecision;