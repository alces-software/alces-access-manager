require('../../modules/es6.typed.float64-array');
module.exports = require('../../modules/_core').Float64Array;