require('../../modules/es6.math.expm1');
module.exports = require('../../modules/_core').Math.expm1;