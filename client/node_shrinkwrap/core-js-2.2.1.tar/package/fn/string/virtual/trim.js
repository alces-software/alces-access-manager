require('../../../modules/es6.string.trim');
module.exports = require('../../../modules/_entry-virtual')('String').trim;