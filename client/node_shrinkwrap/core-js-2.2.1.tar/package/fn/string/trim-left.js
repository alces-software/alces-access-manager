require('../../modules/es7.string.trim-left');
module.exports = require('../../modules/_core').String.trimLeft;