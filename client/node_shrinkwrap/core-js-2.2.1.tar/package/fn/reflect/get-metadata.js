require('../../modules/es7.reflect.get-metadata');
module.exports = require('../../modules/_core').Reflect.getMetadata;