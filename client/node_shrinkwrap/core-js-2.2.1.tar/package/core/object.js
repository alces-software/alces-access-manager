require('../modules/core.object.is-object');
require('../modules/core.object.classof');
require('../modules/core.object.define');
require('../modules/core.object.make');
module.exports = require('../modules/_core').Object;
