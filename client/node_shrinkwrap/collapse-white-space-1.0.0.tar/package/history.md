---
mdast:
  setext: true
---

<!--lint disable no-multiple-toplevel-headings -->

1.0.0 / 2015-07-12
==================
