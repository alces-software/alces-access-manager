export { default } from './forEachRight'
