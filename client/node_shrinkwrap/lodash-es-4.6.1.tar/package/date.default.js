import now from './now';

export default {
  now
};
