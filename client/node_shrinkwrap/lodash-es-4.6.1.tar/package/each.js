export { default } from './forEach'
