export { default as clamp } from './clamp';
export { default as inRange } from './inRange';
export { default as random } from './random';
export { default as default } from './number.default';
