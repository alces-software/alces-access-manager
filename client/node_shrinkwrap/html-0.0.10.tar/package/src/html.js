//= github://einars/js-beautify/[beautify, beautify-html]

module.exports = {
	prettyPrint: style_html
};