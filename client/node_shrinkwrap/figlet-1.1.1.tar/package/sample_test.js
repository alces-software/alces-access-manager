var figlet = require('./lib/node-figlet.js');

figlet.text('pizzapie', {
    font: 'Bloody',
    horizontalLayout: 'full',
    printDirection: 0
}, function(err, data) {
	console.log(data);
});