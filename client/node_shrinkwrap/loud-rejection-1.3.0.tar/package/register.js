'use strict';

require('./')();
