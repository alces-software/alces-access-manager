1.0.1 / 2015-03-04
==================

  * Merge pull request #2 from simonzack/master
  * fixes `.stack` on firefox

1.0.0 / 2013-06-08
==================

  * readme: change travis and component urls
  * refactor: [*] prepare for move to chaijs gh org

0.1.0 / 2013-04-07
==================

  * test: use vanilla test runner/assert
  * pgk: remove unused deps
  * lib: implement
  * "Initial commit"
