# 2.0.0

* Upgraded to PostCSS 5.

# 1.0.1

* Fixes an integration issue with cssnano & cssnext, caused by processors that
  do not expose a `postcssPlugin` property.

# 1.0.0

* Initial release.
