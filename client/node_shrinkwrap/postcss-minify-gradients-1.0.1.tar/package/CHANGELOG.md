# 1.0.1

* Reduce function iterations (thanks to @TrySound).

# 1.0.0

* Initial release.
