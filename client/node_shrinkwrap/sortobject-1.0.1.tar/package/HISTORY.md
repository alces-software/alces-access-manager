# History

## v1.0.1 2016 January 27
- Fixed Firefox compatibility issue
	- Thanks to [Serge Havas](https://github.com/Sinewyk) for [pull request #2](https://github.com/bevry/sortobject/pull/2)
- Updated base files

## v1.0.0 2013 April 20
- Initial working version
