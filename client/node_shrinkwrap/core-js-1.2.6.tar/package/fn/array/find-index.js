require('../../modules/es6.array.find-index');
module.exports = require('../../modules/$.core').Array.findIndex;