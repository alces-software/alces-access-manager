require('../../modules/es6.reflect.get-own-property-descriptor');
module.exports = require('../../modules/$.core').Reflect.getOwnPropertyDescriptor;