'use strict';

module.exports = require('react/lib/ReactDOM');
