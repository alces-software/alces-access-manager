require("babel-helper-plugin-test-runner")(__dirname);
