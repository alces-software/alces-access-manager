module.exports = {
  'add': require('./add'),
  'ceil': require('./ceil'),
  'floor': require('./floor'),
  'max': require('./max'),
  'maxBy': require('./maxBy'),
  'mean': require('./mean'),
  'min': require('./min'),
  'minBy': require('./minBy'),
  'round': require('./round'),
  'subtract': require('./subtract'),
  'sum': require('./sum'),
  'sumBy': require('./sumBy')
};
