# babel-runtime

Babel self-contained runtime

For more information please look at [babel](https://github.com/babel/babel).
