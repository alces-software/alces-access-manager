module.exports = {
  "default": require("core-js/library"),
  __esModule: true
};
